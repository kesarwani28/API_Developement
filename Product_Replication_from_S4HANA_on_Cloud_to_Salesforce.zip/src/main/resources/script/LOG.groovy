import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.lang.StringBuffer;

def Message processData(Message message) {
    //Body
    def messageLog = messageLogFactory.getMessageLog(message);
    
    def logP = message.getProperty("logP") as String;
    def logH = message.getProperty("logH") as String;
    def logB = message.getProperty("logB") as String;
    String content = "";
    
    if(messageLog != null) {
        messageLog.setStringProperty("Logging#1", "Payload");
        
        if (logP != null && logP.equalsIgnoreCase("yes")) {
            def propertyMap = message.getProperties();
            StringBuffer buffer = new StringBuffer();
            for (Map.Entry<String, String> entry : propertyMap.entrySet()) {
                buffer.append("<").append(entry.getKey()).append(">");
                buffer.append(entry.getValue());
                buffer.append("</").append(entry.getKey()).append(">\n");
            }
            content = content + "\n" + buffer.toString();
        }
        
        if (logH != null && logH.equalsIgnoreCase("yes")) {
            def header = message.getHeaders() as String;
            content = content + "\n" + header;
        }
        
        if (logB == null || logB.equalsIgnoreCase("yes")) {
            def body = message.getBody(java.lang.String) as String;
            content = content + "\n" + body;
        }
        
        if (content.length() > 0) {
            messageLog.addAttachmentAsString("MessageLog", content, "text/plain");    
        }
    }

    return message;
}