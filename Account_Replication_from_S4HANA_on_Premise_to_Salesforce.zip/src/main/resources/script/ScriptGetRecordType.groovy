import com.sap.it.api.mapping.*;

def String getRecordType(String arg){
	switch(arg){
	   case 'CUST':
	        return 'SAPSoldTo';
	        break;
	   case 'CUST2':
	        return '';
	        break;
	   default:
	        return '';
	        break;
	}
}