
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.*;

def Message processData(Message message) {
    
    def headers = message.getHeaders();
    def propertyMap = message.getProperties();
    String orderItems = propertyMap.get('orderItems');
    def body = message.getBody(java.lang.String) as String;
    
    XmlParser xmlParser = new XmlParser();
    def xmlBody = xmlParser.parseText(body);

    def lineKeys = [];
    def xmlOrderItems = xmlParser.parseText(orderItems);
    xmlOrderItems.'**'.findAll({ it -> it.name() == 'SAP_Order_Line_Key__c' }).each({ it -> lineKeys.push(it.text())});
    
    def removeList = xmlBody.'**'.findAll({it -> it.name() == 'A_SalesOrderItemType'});
    removeList.each({ it ->
        if(lineKeys.contains(it.SalesOrderItem[0].text()))
            it.parent().remove(it);
    })
    
    message.setBody(XmlUtil.serialize(xmlBody));
    
    return message;
}