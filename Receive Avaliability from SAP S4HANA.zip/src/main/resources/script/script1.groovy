import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
   def qtyPro = message.getProperty("qty") as String;
   if (qtyPro == null || qtyPro.length() == 0) {
       message.setProperty("qty", "1");
   }
   return message;
}