import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.*;

def Message processData(Message message) {
    
    //Body 
    def body = message.getBody(java.lang.String) as String;
    if(body.contains('urn:partner.soap.sforce.com'))
    {
        body = body.replace('<n1:','<').replace('</n1:','</')
    }
    
    XmlParser parser = new XmlParser();
    def xml = parser.parseText(body);
    
    def ids = '';
    xml.'**'.findAll({ it -> it.name() == 'SAP_Order_Line_Key__c'}).each({it -> 
        if(ids == '')
            ids = it.text();
        else 
            ids += ',' + it.text();
    });
    
    message.setProperty("ids",ids); 
    message.setBody(XmlUtil.serialize(xml));
    return message;
}