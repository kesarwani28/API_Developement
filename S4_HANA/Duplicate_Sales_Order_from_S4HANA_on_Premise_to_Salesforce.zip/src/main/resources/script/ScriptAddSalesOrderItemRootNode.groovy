
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.*;

def Message processData(Message message) {
    //Body 
    def body = message.getBody(java.lang.String) as String;
    
    XmlParser parser = new XmlParser()
    def newRoot = parser.parseText("<A_BusinessPartner></A_BusinessPartner>");
    def bodyXML = parser.parseText(body);
    newRoot.append(bodyXML);

    message.setBody(XmlUtil.serialize(newRoot));
    
    return message;
}