import com.sap.it.api.mapping.*;

def String formatOrderItemLineKey(String arg1, String arg2){
	return arg1.padLeft(10,'0') + arg2.padLeft(6,'0');
}