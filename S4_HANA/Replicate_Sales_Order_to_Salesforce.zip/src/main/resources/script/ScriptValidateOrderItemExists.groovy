import com.sap.it.api.mapping.*;

def String validateOrderItemExists(String arg, MappingContext context){
    
    String idsString = context.getProperty('ids');
    def ids = idsString.split(',');
    if(ids.length > 0 && ids.contains(arg))
        return 'true';
    
	return 'false'; 
}