import com.sap.it.api.mapping.*;

def String getOrderStatus(String arg){
	switch(arg) {
	    case "A":
	        return "Activated";
	        break;
	    case "B":
	        return "In Approval Process";
	        break;
	    case "C":
	        return "Draft";
	        break;
	    default:
	        return "Draft";
	        break;
	}
}
