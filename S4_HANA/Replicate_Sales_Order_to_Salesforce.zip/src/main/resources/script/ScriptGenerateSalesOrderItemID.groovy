import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.*;

def Message processData(Message message) {
    
    //Body 
    def body = message.getBody(java.lang.String) as String;
    
    XmlParser parser = new XmlParser();
    def xml = parser.parseText(body);
    def recordTypes = xml.'**'.findAll({ it -> it.name() == 'SalesOrder' });
    recordTypes.each({ it ->
        def id = it.text();
        id = id.padLeft( 10, '0' );
        it.replaceBody(id);
    })
    
    
    def messageLog = messageLogFactory.getMessageLog(message);
    if(messageLog != null) {
        messageLog.setStringProperty("Logging#1", "ScriptPadWithLeadingZeros");
        messageLog.addAttachmentAsString("ScriptPadWithLeadingZeros:", "Before\n" + groovy.xml.XmlUtil.serialize(new XmlParser().parseText(body)).toString() + "\nAfter\n" + groovy.xml.XmlUtil.serialize(xml).toString(), "text/plain");
    }
    
    
    message.setBody(XmlUtil.serialize(xml));
    
    return message;
}